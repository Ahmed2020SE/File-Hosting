

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.omg.CORBA.portable.ApplicationException;
import com.foura.database.Database;
import com.foura.servlet.EmailMessage;
import com.foura.servlet.SendMail;

/**
 * Servlet implementation class forgotProcess
 */
@WebServlet("/forgotProcess")
public class forgotProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public forgotProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String pass=Database.forget(email);
		EmailMessage msg=new EmailMessage();
		msg.setTo(email);
		msg.setMessage("your password: "+pass);
		msg.setSubject("Password Reset");
		msg.setMessageType(2);
		if (pass==null||pass=="") {
			request.setAttribute("forgetMsg", "Invalid Email !");
			request.getRequestDispatcher("/forgetPassword.jsp").forward(request, response);
		} else {
			try {
				SendMail.sendMail(msg);
			} catch (ApplicationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("forgetMsg", "Password send to your email id successfully !");
			request.getRequestDispatcher("/forgetPassword.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
