package com.foura.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterValidation {
	private static final String EMAIL_REGEX = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";

	// static Pattern object, since pattern is fixed
	private static Pattern pattern;

	// non-static Matcher object because it's created from the input String
	private static Matcher matcher;
    public RegisterValidation(){
    	pattern = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
    }
	public static boolean validateEmail(String email) {
		matcher = pattern.matcher(email);
		return matcher.matches();
	}
    public boolean validate(String fullname,String username,String email,String password,String conpassword){
    	if (fullname == null || fullname == "") {
			return false;
		} else if (email == null || email == ""|| (validateEmail(email))==false) {
			return false;
		} else if (username == null || username == "") {
			return false;
		} else if (password.length() < 6) {
			return false;
		} else if (!password.equals(conpassword)) {
			return false;
		}
		return true;
    }
    public String validatemsg(String fullname,String username,String email,String password,String conpassword){
    	if (fullname == null || fullname == "") {
			return "Name cannot be empty" ;
		} else if (email == null || email == ""|| (validateEmail(email))==false) {
			return "Make sure you entered email";
		} else if (username == null || username == "") {
			return "Make sure you entered username" ;
		} else if (password.length() < 6) {
			return "Password cannot be less than 6 characters";
		} else if (!password.equals(conpassword)) {
			return "confirm password mismatch the password" ;
		}
		return "Fill the information.";
    }
}
