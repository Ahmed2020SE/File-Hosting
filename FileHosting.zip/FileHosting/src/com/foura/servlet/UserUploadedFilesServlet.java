package com.foura.servlet;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.foura.database.Database;

@WebServlet(description = "List The Already Uploaded Files", urlPatterns = { "/userUploadedFilesServlet" })
public class UserUploadedFilesServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6710043129241921841L;
	//private static final long serialVersionUID = 1L;
	public static final String UPLOAD_DIR = "uploadedFiles";

	/*****
	 * This Method Is Called By The Servlet Container To Process A 'GET' Request
	 *****/
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			handleRequest(request, response);
	}

	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String applicationPath = getServletContext().getRealPath(""),
				uploadPath = applicationPath + File.separator + UPLOAD_DIR;
		File fileUploadDirectory = new File(uploadPath);
		System.out.println(fileUploadDirectory.exists());
		if (!fileUploadDirectory.exists()) {
			fileUploadDirectory.mkdirs();
		}
		UploadDetail userDetails = null;
		File[] allFiles = fileUploadDirectory.listFiles();
		List<UploadDetail> userFileList = new ArrayList<UploadDetail>();
		HttpSession session = request.getSession();
		int uid = (int) session.getAttribute("UID");
		ArrayList<String> ls=Database.userFiles(uid);
		int i=0;
		while (i<ls.size()) {
			String filename =ls.get(i); 
			for (File file : allFiles) {
				System.out.println(file.getName());
				if (file.getName().equals(filename)) {
					userDetails = new UploadDetail();
					userDetails.setFileName(file.getName());
					userDetails.setFileSize(file.length() / 1024);
					userFileList.add(userDetails);
				}
			}
			i++;
		}
		System.out.println(uid);
		System.out.println("Exist files: "+userFileList.size());
		session.setAttribute("useruploadedFiles", userFileList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/userPage.jsp");
		dispatcher.forward(request, response);
	}
}