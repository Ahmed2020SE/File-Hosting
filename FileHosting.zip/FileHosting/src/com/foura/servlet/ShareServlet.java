package com.foura.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShareServlet
 */
@WebServlet("/shareServlet")
public class ShareServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		handleRequest(request, response);
	}

	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("shareLink", ("http://localhost:8089/" + request.getContextPath()
				+ "/downloadServlet?fileName=" + (String) request.getParameter("shareName")));
		request.getRequestDispatcher("/share.jsp").forward(request, response);
	}

}
