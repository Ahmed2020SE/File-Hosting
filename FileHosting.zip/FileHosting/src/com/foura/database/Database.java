package com.foura.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.foura.bean.LoginBean;
import com.foura.bean.RegisterBean;

public class Database {
	private static Connection con = null;
	private static PreparedStatement pstmt = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;

	public static boolean emailExist(String email) {
		String query = "SELECT COUNT(1) FROM user WHERE email = ? ";
		int emailCount = 0;
		con = DBConnection.createConnection();
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,email);
			ResultSet rs = pstmt.executeQuery();
			emailCount = rs.getInt(1);
		} catch (SQLException ex) {
			System.out.println("exception in count email");
		} finally {
			try {
				con.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (emailCount == 1) {
			return true;
		}
		return false;
	}

	public static boolean userExist(String username) {

		int userCount = 0;
		con = DBConnection.createConnection();
		String query = "SELECT COUNT(1) FROM user WHERE userName = ? ";
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			userCount = rs.getInt(1);
		} catch (SQLException ex) {
			System.out.println("exception in count user");
		} finally {
			try {
				con.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (userCount == 1) {
			return true;
		}
		return false;
	}

	public static String registerUser(RegisterBean registerBean) {
		String fullName = registerBean.getFullName();
		String email = registerBean.getEmail();
		String userName = registerBean.getUserName();
		String password = registerBean.getPassword();
		if (emailExist(email) == false&&userExist(userName)==false) {
			try {
				con = DBConnection.createConnection();
				String query = "insert into user(fullName,Email,userName,password) values (?,?,?,?)";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, fullName);
				pstmt.setString(2, email);
				pstmt.setString(3, userName);
				pstmt.setString(4, password);
				int i = pstmt.executeUpdate();

				if (i != 0) {
					return "Database work";
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					con.close();
					pstmt.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}

			}
		}
		return "Email Already exist or UserName Already exist";

	}

	public static String authenticateUser(LoginBean loginBean) {
		con = DBConnection.createConnection();
		String userName = loginBean.getUserName();
		String password = loginBean.getPassword();
		String userNameDB = "";
		String passwordDB = "";

		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("select userName,password from user");

			while (rs.next()) {
				userNameDB = rs.getString("userName");
				passwordDB = rs.getString("password");

				if (userName.equals(userNameDB) && password.equals(passwordDB)) {
					return "SUCCESS";
				} else if (userName == "" || password == "") {
					return "Invalid user credentials";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
				stmt.close();
				rs.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return "Invalid user credentials"; // Just returning appropriate message
											// otherwise
	}

	public static void contact(String fname, String lname, String email, String subj, String mgs) {
		con = DBConnection.createConnection();
		try {
			pstmt = con.prepareStatement("insert into contact(fname,lname,email,subject,message) values(?,?,?,?,?)");
			pstmt.setString(1, fname);
			pstmt.setString(2, lname);
			pstmt.setString(3, email);
			pstmt.setString(4, subj);
			pstmt.setString(5, mgs);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void newPassword(String pass, String username) {
		con = DBConnection.createConnection();
		try {
			stmt = con.createStatement();
			stmt.executeUpdate("update user set password='" + pass + "' where userName='" + username + "'");
		} catch (

		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static ArrayList<String> userFiles(int uid) {
		con = DBConnection.createConnection();
		ArrayList<String> list = new ArrayList<>();
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("select name from files f where f.user_UID=" + uid);
			while (rs.next()) {
				list.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
				stmt.close();
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;

	}

	public static void insertfile(String filename, int uid) {
		con = DBConnection.createConnection();
		try {
			pstmt = con.prepareStatement("insert into files(name,user_UID) values(?,?)");
			pstmt.setString(1, filename);
			pstmt.setInt(2, uid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static String Email(String filename) {
		String email = "";
		con = DBConnection.createConnection();
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("select Email from user u where u.UID=(select user_UID from files f where f.name='"
							+ filename + "')");
			email = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
				stmt.close();
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return email;
	}

	public static void delete(int uid, String fileName) {
		con = DBConnection.createConnection();
		try {
			pstmt = con.prepareStatement("delete from files where name=? and user_UID=?");
			pstmt.setString(1, fileName);
			pstmt.setInt(2, uid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static String forget(String email) {
		Connection con = DBConnection.createConnection();
		String pass = "";
		try {
			stmt = con.createStatement();
			String strQuery = "select password from users where Email='" + email + "'";
			rs = stmt.executeQuery(strQuery);
			pass = rs.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pass;
	}
}
