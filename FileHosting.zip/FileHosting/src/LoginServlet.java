

import com.foura.bean.LoginBean;
import com.foura.database.DBConnection;
import com.foura.database.Database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int uid;
	private String fullName;
	private String email;
	private Date dt;
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("username");
        String password = request.getParameter("password");

        LoginBean loginBean = new LoginBean();

        loginBean.setUserName(userName);
        loginBean.setPassword(password);
        request.setAttribute("loginBean", loginBean);
        HttpSession session = request.getSession();
		session.setAttribute("userName",userName);
		Connection con = DBConnection.createConnection();
		Statement stmt;
		ResultSet rs;
		dt = new Date();
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from user");
			while (rs.next()) {
				if (rs.getString(4).equals(userName)) {
					uid=rs.getInt(1);
					fullName=rs.getString(2);
					email=rs.getString(3);
					dt=rs.getTimestamp(6);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		System.out.println("UserName: "+userName);
		System.out.println("UID: "+uid);
		session.setAttribute("UID", uid);
		session.setAttribute("fullname", fullName);
		session.setAttribute("email", email);
		session.setAttribute("date", dt);
        String userValidate = Database.authenticateUser(loginBean);

        if (userValidate.equals("SUCCESS")) {   
            response.sendRedirect("userUploadedFilesServlet");

        } else {
            request.setAttribute("errMessage", userValidate);
            request.getRequestDispatcher("/Login.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
