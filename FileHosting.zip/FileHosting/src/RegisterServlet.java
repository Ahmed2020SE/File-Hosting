
import com.foura.bean.RegisterBean;
import com.foura.database.Database;
import com.foura.bean.RegisterValidation;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/RegisterServlet" })
public class RegisterServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String fullName = request.getParameter("fullname");
		String email = request.getParameter("email");
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		String copass = request.getParameter("conpassword");
		if (fullName != null) {
			request.setAttribute("fullname", fullName);
		}
		if (email != null) {
			request.setAttribute("email", email);
		}
		if (userName != null) {
			request.setAttribute("username", userName);
		}
		RegisterBean registerBean = new RegisterBean();
		registerBean.setFullName(fullName);
		registerBean.setEmail(email);
		registerBean.setUserName(userName);
		registerBean.setPassword(password);
		registerBean.setCopass(copass);
		String userRegistered = Database.registerUser(registerBean);
		RegisterValidation validation=new RegisterValidation();
		boolean valid = validation.validate(fullName, userName, email, password, copass);
		System.out.println("Validation: "+valid);
		System.out.println("Database: "+userRegistered);
		if (valid == true) {
			if (userRegistered.equals("Database work")) {
				request.getRequestDispatcher("/Login.jsp").forward(request, response);
			} else if (userRegistered.equals("Email Already exist or UserName Already exist")) {
				request.setAttribute("errMessage", "Email Already exist or UserName Already exist");
				request.getRequestDispatcher("/Register.jsp").forward(request, response);
				response.sendRedirect("Register.jsp");
			}
		}
		else{
			request.setAttribute("errMessage", validation.validatemsg(fullName, userName, email, password, copass));
			request.getRequestDispatcher("/Register.jsp").forward(request, response);
		}
	}

	@Override
	public String getServletInfo() {
		return "Short description";
	}

}
